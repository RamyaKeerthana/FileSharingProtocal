
->unzip the file

for Client1.c
->cd Client1
->gcc Client1.c  IndexGet.c manage.c  Hashing.c filetransfer.c udp.c -o Exec
->./Exec 10.1.130.138
->0 for tcp and 1 for udp


for Client2
->cd server
->gcc filehash.c filetransfer.c indexget.c manage.c server1.c udp.c
->./a.out 10.1.130.59 0  (for tcp)
->./a.out 10.1.130.59 1 filename (for udp)


Commands for tcp

->IndexGet<space>LongList

->IndexGet<space>ShortList<space>starting-timestamp<space>ending-time-stamp<CRLF/EOL>

->IndexGet<space>RegEx<space>"*mp3"<CRLF/EOL>

->FileHash<space>Verify<space>Name-of-file<CRLF/EOL>


->FileHash<space>CheckAll<CRLF/EOL>


->FileDownload<space>Name-of-file<CRLF/EOL>

->FileUpload<space>Name-of-file<CRLF/EOL>

For UDP

->give argument2 as 1  and filename to be tramsfered as argument3.The other client can download this transfered file.


