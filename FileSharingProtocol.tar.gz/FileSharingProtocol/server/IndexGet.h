#ifndef INDEX_GET
#define INDEX_GET
extern pid_t pid;
extern void cIndexget(char x[],int *a);
extern void Indexget(char x[] ,int *a);
#endif