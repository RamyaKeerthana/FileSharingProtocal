#ifndef UDP
#define UDP
int duration (struct timeval *start,struct timeval *stop, struct timeval *delta);
int create_server_socket (int port);
int client(char *ip,char *filen);
int server();
struct sockaddr_in sock_serv1,clt;
int create_client_socket (int port, char* ipaddr);
struct sockaddr_in sock_serv;
#endif
