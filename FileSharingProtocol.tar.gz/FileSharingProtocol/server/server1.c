#include <stdio.h>
#include <stdlib.h>
#include<signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include<arpa/inet.h>
#include "filehash.h"
#include "filetransfer.h"
#include "indexget.h"
#include "manage.h"
#include "udp.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <sys/uio.h>

void error(const char *msg)
{
    perror(msg);
    exit(0);
}
pid_t pid;
int main(int argc, char *argv[])
{
	if (argc < 3) 
	{
		fprintf(stderr,"usage %s hostname \n", argv[0]);
	        exit(0);
    	}
	//printf("%s",argv[1]);
	
	pid=fork();
	if(pid==0)
	{
		if(atoi(argv[2])==0)
		{
			manage_peer(argv[1]);
		}
		else if(atoi(argv[2])==1)
		{
			//printf("%s,%s\n",argv[1],argv[3]);
			client(argv[1],argv[3]);
		}
	
	
	}
	
		
	else if(pid)
	{
		if(atoi(argv[2])==0)
		{
			manage_host();
		}
		else if(atoi(argv[2])==1)
		{
			//server();	
		}
	}	

	return 0;
}





