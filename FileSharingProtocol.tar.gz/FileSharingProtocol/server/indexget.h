#ifndef INDEX
#define INDEX
extern pid_t pid;
extern void Indexget(char read_buffer[],int *newsockfd);
extern void cIndexget(char write_buffer[],int *sockfd);
#endif		
		
