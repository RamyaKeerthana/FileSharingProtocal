#ifndef MANAGE
#define MANAGE
extern pid_t pid;
void manage_peer(char *ip);
void manage_host();
#endif

