#ifndef FILETRANSFER
#define FILETRANSFER
extern pid_t pid;
extern void cFiledownload(char write_buffer[],int *sockfd);
extern void Filedownload(char read_buffer[],int *newsockfd);
extern void cFileupload(char write_buffer[],int *sockfd);
extern void Fileupload(char read_buffer[],int *newsockfd);
#endif
	
