#ifndef FILEHASH
#define FILEHASH
extern pid_t pid;
extern void Filehash(char read_buffer[] , int *newsockfd);
extern void hashing(char l1[],int *newsockfd);
extern void cFilehash(char write_buffer[], int *sockfd);
#endif
