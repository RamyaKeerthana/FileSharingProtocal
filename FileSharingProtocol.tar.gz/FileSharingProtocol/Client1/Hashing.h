#ifndef HASH_ING
#define HASH_ING
extern pid_t pid;
extern void cFilehash(char x[], int *a);
extern void Filehash(char [],int *a);
extern void hashing(char l1[],int *ne);
#endif
