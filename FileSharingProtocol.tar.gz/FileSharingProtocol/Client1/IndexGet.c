#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include "IndexGet.h"
void Indexget(char read_buffer[],int *newsockfd)
{
	char write_buffer[1024];
	bzero(write_buffer,1024);
	char l[8]="LongList",r[5]="RegEx",s[9]="ShortList";
	int t=0,i;
	for(i=0;i<8;i++)
		if(l[i]!=read_buffer[9+i])
			t=1;
	if(t==1)
	{
		for(i=0;i<5;i++)
			if(r[i]!=read_buffer[9+i])
				t=2;
	}
	if(t==2)
	{
		for(i=0;i<9;i++)
			if(s[i]!=read_buffer[9+i])
				t=3;
	}
	if(t==0)
	{
		system("touch Result");
		system("ls -l |grep -v ^d | tr -s ' ' | awk '{print $9\"\\t\"$5\"\\t\"$8}'| tail -n +2 > Result");
		bzero(write_buffer, 1024);
		int f=0,flag=0;
		FILE *fs = fopen("Result", "r");
		if(fs == NULL)
		{
			error("ERROR: File not found");
			exit(1);
		}
		while((f= fread(write_buffer, sizeof(char),1024, fs)) > 0)
		{
			if(write(*newsockfd, write_buffer, 1024) < 0)
			{
				error("\nERROR: Writing to socket");
				exit(1);
				break;
			}
			bzero(write_buffer, 1024);
			flag=1;
		}
		if(flag==1)
		{
		bzero(write_buffer, 1024);
		strcpy(write_buffer,"END");
		if(write(*newsockfd, write_buffer, 1024) < 0)
		{
			error("\nERROR: Writing to socket");
			exit(1);
		}
		}
		system("rm -rf Result");

	}
	if(t==1)
	{
		char st[500],str[400];
		int k=0;
		i=15;
		while(i!=strlen(read_buffer))
		{
			st[k]=read_buffer[i];
			k++;
			i++;
		}
		st[k]='\0';
		strcpy(str,"find . -name \"");
		strcat(str,st);
		strcat(str,"\" -exec ls -l {} \\; | awk '{print $9\"\\t\"$5}' | cut -c "" 3- > Result");
		system("touch Result");
		system(str);

		bzero(write_buffer, 1024);
		int f=0,flag=0;
		FILE *fs = fopen("Result", "r");
		if(fs == NULL)
		{
			error("ERROR: File not found");
			exit(1);
		}
		while((f= fread(write_buffer, sizeof(char),1024, fs)) > 0)
		{
			if(write(*newsockfd, write_buffer, 1024) < 0)
			{
				error("\nERROR: Writing to socket");
				exit(1);
				break;
			}
			bzero(write_buffer, 1024);
			flag=1;
		}
		if(flag==1)
		{
		bzero(write_buffer, 1024);
		strcpy(write_buffer,"END");
		if(write(*newsockfd, write_buffer, 1024) < 0)
		{
			error("\nERROR: Writing to socket");
			exit(1);
		}
		system("rm -rf Result");
		}
	}
	if(t==2)
	{
		char st[400],str[400];
		int k=0,flag=0;
		i=19;
		while(read_buffer[i]!=' ')
		{
			st[k]=read_buffer[i];
			k++;
			i++;
		}
		st[k]='\0';
		k=0;
		i++;
		while(read_buffer[i]!='\0')
		{
			str[k]=read_buffer[i];
			k++;
			i++;
		}
		str[k]='\0';
		//printf("a%sa b%sb\n",st,str);
		system("touch fd");
		system("ls --full-time|grep -v ^d | awk '{print $9\"\\t\"$5\"\\t\"$7}' | tail -n +2 | sort -n > fd");
		FILE *file = fopen ( "fd", "r" );
		FILE *file1 = fopen("result","w");
		if ( file != NULL )
		{
			char line [400];
			while ( fgets ( line, sizeof(line), file ) != NULL )
			{
				char te[400];
				i=0;
				k=0;
				while(line[i]!=' ')
					i++;
				i++;
		//		printf("%c\n",line[i]);
				while(line[i]!=' ')
					i++;
				i++;
		//		printf("%c\n",line[i]);
				while(i!=strlen(line)-1)
				{
					te[k]=line[i];
					k++;
					i++;
				}
				if(strcmp(te,st)>=0&&strcmp(te,str)<=0)
				{
					fputs(line,file1);
				}
			}
			fclose ( file );
			fclose(file1);
		}
		else
			error("Error in file opening");
		file1=fopen("result","r");
		if(file1!=NULL)
		{
		//	printf("send");
			int f=0;
		while((f= fread(write_buffer, sizeof(char),1024, file1)) > 0)
		{
			if(write(*newsockfd, write_buffer, 1024) < 0)
			{
				error("\nERROR: Writing to socket");
				exit(1);
				break;
			}
			bzero(write_buffer, 1024);
			flag=1;
		}
		if(flag==1)
		{
		bzero(write_buffer, 1024);
		strcpy(write_buffer,"END");
		if(write(*newsockfd, write_buffer, 1024) < 0)
		{
			error("\nERROR: Writing to socket");
			exit(1);
		}
		system("rm -rf fd");
		system("rm -rf result");
		}
		}
		else
			error("Error in file opening");


	}
}

void cIndexget(char write_buffer[],int *sockfd)
{
	int n;
	n = write(*sockfd,write_buffer,1024);
	if (n < 0)
		error("ERROR writing to socket");
	char l[8]="LongList",read_buffer[1024],r[5]="RegEx",s[9]="ShortList";
	int t=0,i;
	for(i=0;i<8;i++)
		if(l[i]!=write_buffer[9+i])
			t=1;
	if(t==1)
	{
		for(i=0;i<5;i++)
			if(r[i]!=write_buffer[9+i])
				t=2;
	}
	if(t==2)
	{
		for(i=0;i<9;i++)
			if(s[i]!=write_buffer[9+i])
				t=3;
	}
	if(t==0)
	{

		int f=0,flag=1;
		bzero(read_buffer, 1024);
		printf("\nRecieved data : %s\n",read_buffer);
		printf("File-name Size Timestamp\n");
		while((f= read(*sockfd, read_buffer,1024)) > 0)
		{
			if(strcmp(read_buffer,"END")==0)
			{flag=0;
				break;
			}
			else
				printf("%s\n",read_buffer);
		}
		if(flag==1)
		exit(0);
	}
	if(t==1)
	{
		int f=0,flag=1;
		bzero(read_buffer, 1024);
		printf("\nRecieved data : %s\n",read_buffer);
		printf("File-name Size\n");
		while((f= read(*sockfd, read_buffer,1024)) > 0)
		{
			if(strcmp(read_buffer,"END")==0)
			{flag=0;
				break;
			}
			else
				printf("%s\n",read_buffer);
		}
		if(flag==1)
		exit(0);
	}
	if(t==2)
	{
		int f=0,flag=1;
		bzero(read_buffer, 1024);
		printf("\nRecieved data : %s\n",read_buffer);
		printf("File-name Size Last-Modified Timestamp\n");
		while((f= read(*sockfd, read_buffer,1024)) > 0)
		{
			if(strcmp(read_buffer,"END")==0)
			{flag=0;
				break;
			}
			else
				printf("%s\n",read_buffer);
		}
		if(flag==1)
		exit(0);
	}
}

