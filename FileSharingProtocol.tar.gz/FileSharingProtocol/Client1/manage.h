#ifndef MANAGE
#define MANAGE
extern pid_t pid;
extern void manage_peer(char *ip);
extern void manage_host();
#endif

