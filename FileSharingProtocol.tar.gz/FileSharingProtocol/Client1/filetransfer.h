#ifndef FILETRANSFER
#define FILETRANSFER
extern pid_t pid;
extern void cFiledownload(char x[],int *a);
extern void Filedownload(char x[],int *a);
extern void cFileupload(char x[],int *a);
extern void Fileupload(char x[],int *a);
#endif
	