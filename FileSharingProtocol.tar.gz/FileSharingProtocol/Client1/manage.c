#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "manage.h"
void manage_peer(char *ip)
{
	int sockfd, portno, n;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char read_buffer[1024],write_buffer[1024];

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
        error("ERROR opening socket");
    else
	    printf("[Client] Socket created\n");

    server = gethostbyname(ip);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(5001);
    serv_addr.sin_addr = *((struct in_addr *)server->h_addr);
    bzero(&(serv_addr.sin_zero),8);

    while(connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
    {
	    sleep(1);
    }
    while(1)
   {
		bzero(write_buffer , 1024);
		printf("Enter the message : ");
		gets(write_buffer);
		printf("\n");
		if(strcmp(write_buffer , "Q")==0 || strcmp(write_buffer , "q")==0)
		{
    			n = write(sockfd,write_buffer,1024);
    			if (n < 0)
        			 error("ERROR writing to socket");
			printf("[Client] Connection closed\n");
			kill(pid,SIGTERM);
			break;
		//	exit(0);
		}
		else if(strncmp(write_buffer,"IndexGet",8)==0)
		{
			cIndexget(write_buffer,&sockfd);
		}
		else if(strncmp(write_buffer,"FileHash",8)==0)
		{
			cFilehash(write_buffer,&sockfd);
		}
		else if(strncmp(write_buffer,"FileDownload",12)==0)
		{
			cFiledownload(write_buffer,&sockfd);
		}
		else if(strncmp(write_buffer,"FileUpload",10)==0)
		{
			cFileupload(write_buffer,&sockfd);
		}
		else
		{
    			n = write(sockfd,write_buffer, 1024);
    			if (n < 0)
        			 error("ERROR writing to socket");
		}
   }
   close(sockfd);
   _exit(0);
    return ;
}

void manage_host()
{
	int sockfd, newsockfd;
	socklen_t cli_len;
	struct hostent *server1;
	server1 = gethostbyname("10.1.130.59");
	char read_buffer[1024];
	struct sockaddr_in servi_addr, cli_addr;
	int n,i;
	char commands[1000][100];
	int flag[1000],h=0;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		error("ERROR opening socket");
	else
		printf("[Server] Socket intialized \n");

	bzero((char *) &servi_addr, sizeof(servi_addr));
	servi_addr.sin_family = AF_INET;
	servi_addr.sin_addr = *((struct in_addr *)server1->h_addr);
	servi_addr.sin_port = htons(5002);

	if (bind(sockfd, (struct sockaddr *) &servi_addr, sizeof(servi_addr)) < 0)
		error("ERROR on binding");
	else
		printf("[Server] Socket Binded to the Server Address\n");

	if(listen(sockfd,5) < 0)
		error("ERROR in listening");

	printf("[Server] Server waiting for an client\n");
	fflush(stdout);
//	while(1)
//	{
		cli_len = sizeof(cli_addr);
		newsockfd = accept(sockfd,  (struct sockaddr *) &cli_addr, &cli_len);
		if (newsockfd < 0)
			error("ERROR on accept");


		while(1)
		{
			bzero(read_buffer,1024);
			n= read(newsockfd, read_buffer , 1024);
			if (n < 0)
				error("ERROR writing to socket");
			read_buffer[n]='\0';
			strcpy(commands[h],read_buffer);
			if(strcmp(read_buffer, "q")==0 || strcmp(read_buffer, "Q")==0)
			{
				printf("\nHere is the message: %s\n",read_buffer);
				kill(pid,SIGTERM);
				break;
				//exit(0);
			}
			else if(strncmp(read_buffer , "IndexGet",8)==0)
			{
				Indexget(read_buffer,&newsockfd);
			}
			else if(strncmp(read_buffer,"FileHash",8)==0)
			{
				Filehash(read_buffer,&newsockfd);
			}
			else if(strncmp(read_buffer,"FileDownload",12)==0)
			{
				Filedownload(read_buffer,&newsockfd);
			}
			else if(strncmp(read_buffer,"FileUpload",10)==0)
			{
				Fileupload(read_buffer,&newsockfd);
			}
			else
			{
				printf("\nMessage from peer: %s\n",read_buffer);
				flag[h]=1;
				h++;
			}
			fflush(stdout);
			while(waitpid(-1, NULL, WNOHANG) > 0);
		}
		close(newsockfd);
		printf("\n Connection closed by peer\n");
//	}
	close(sockfd);
	exit(1);
	return ;
}

